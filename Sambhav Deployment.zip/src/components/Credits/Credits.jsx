import React from "react";
import "./Credits.css";

// import images (update filenames if yours are different)
import janmejayImg from "../assets/janmejay.jpg";
import vedantImg from "../assets/vedant.jpg";
import shreerajImg from "../assets/shreeraj.png";
import mayureshImg from "../assets/mayuresh.png";
import tusharImg from "../assets/tushar.png";
import anamImg from "../assets/anam.jpg";
import yashImg from "../assets/yash.jpg";
import nikitaImg from "../assets/nikita.png";

/* --- SVG ICONS --- */
/* LinkedIn: single-color fill (kept as original) */
const LinkedInIcon = () => (
  <svg className="social-svg" viewBox="0 0 24 24" aria-hidden="true" role="img">
    <path
      fill="#0A66C2"
      d="M19.333 0H4.667A4.667 4.667 0 000 4.667v14.666A4.667 4.667 0 004.667 24h14.666A4.667 4.667 0 0024 19.333V4.667A4.667 4.667 0 0019.333 0zM8.064 19.333H4.8V8.73h3.264v10.603zM6.432 7.428a1.664 1.664 0 110-3.328 1.664 1.664 0 010 3.328zm11.36 11.905h-3.264V13.84c0-1.312-.024-2.997-1.824-2.997-1.824 0-2.106 1.428-2.106 2.904v5.586H7.336V8.73h3.128v1.428h.042c.432-.816 1.488-1.68 3.096-1.68 3.312 0 3.924 2.184 3.924 5.022v5.832z"
    />
  </svg>
);

/* Instagram: uses a linearGradient. we accept an idSuffix prop so each instance gets a unique gradient id */
const InstagramIcon = ({ idSuffix = "" }) => {
  const gid = `instaGradient${idSuffix}`;
  return (
    <svg className="social-svg" viewBox="0 0 512 512" aria-hidden="true" role="img">
      <defs>
        <linearGradient id={gid} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fdf497" />
          <stop offset="25%" stopColor="#fd5949" />
          <stop offset="50%" stopColor="#d6249f" />
          <stop offset="75%" stopColor="#285AEB" />
        </linearGradient>
      </defs>
      <path
        fill={`url(#${gid})`}
        d="M349.33 69.33h-186.66C94.47 69.33 69.33 94.47 69.33 162.67v186.66c0 68.2 25.14 93.34 93.34 93.34h186.66c68.2 0 93.34-25.14 93.34-93.34V162.67c0-68.2-25.14-93.34-93.34-93.34zm62.67 280c0 34.47-17.33 51.8-51.8 51.8H162.67c-34.47 0-51.8-17.33-51.8-51.8V162.67c0-34.47 17.33-51.8 51.8-51.8h197.53c34.47 0 51.8 17.33 51.8 51.8v186.66zM256 162.67a93.33 93.33 0 1093.33 93.33A93.33 93.33 0 00256 162.67zm0 153.33a60 60 0 1160-60 60 60 0 01-60 60zm93.33-153.33a22.22 22.22 0 11-22.22-22.22 22.22 22.22 0 0122.22 22.22z"
      />
    </svg>
  );
};

/* --- TEAM MEMBERS (all 8, placeholders for links) --- */
const teamMembers = [
  {
    name: "Janmejay Singh Rathore",
    role: "Team Lead",
    imgSrc: janmejayImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Vedant Darange",
    role: "Co-Lead",
    imgSrc: vedantImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Shreeraj Babar",
    role: "Team Member",
    imgSrc: shreerajImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Mayuresh Kalal",
    role: "Team Member",
    imgSrc: mayureshImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Tushar Pawar",
    role: "Team Member",
    imgSrc: tusharImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Anam Patave",
    role: "Team Member",
    imgSrc: anamImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Yash Badane",
    role: "Team Member",
    imgSrc: yashImg,
    linkedin: "#",
    instagram: "#",
  },
  {
    name: "Nikita Gadalikar",
    role: "Team Member",
    imgSrc: nikitaImg,
    linkedin: "#",
    instagram: "#",
  },
];

export default function Credits() {
  return (
    <section className="credits-page">
      <div className="credits-inner">
        <header className="credits-header">
          <h1 className="credits-main-title">
            The Minds Behind The <span className="text-gradient">WEBSITE</span>
          </h1>
          <p className="credits-subtitle">
            This website was designed and developed by a passionate team of creators.
          </p>
        </header>

        <div className="team-grid">
          {teamMembers.map((member, index) => {
            const roleClass = member.role.toLowerCase().replace(/\s+/g, "-");
            const hasLinkedIn = member.linkedin && member.linkedin !== "#";
            const hasInstagram = member.instagram && member.instagram !== "#";

            return (
              <div className={`team-card ${roleClass}`} key={member.name}>
                <div className="avatar-wrapper">
                  <div
                    className="team-photo"
                    style={{ backgroundImage: `url(${member.imgSrc})` }}
                  />
                  <div className="role-badge">{member.role}</div>
                </div>

                <div className="member-body">
                  <h3 className="team-name">{member.name}</h3>
                  <p className="team-role">{member.role}</p>

                  <div className="team-socials">
                    {/* LinkedIn: open only if real link provided, otherwise anchor is inert */}
                    <a
                      href={hasLinkedIn ? member.linkedin : "#"}
                      onClick={hasLinkedIn ? undefined : (e) => e.preventDefault()}
                      aria-label={`${member.name}'s LinkedIn`}
                      target={hasLinkedIn ? "_blank" : undefined}
                      rel={hasLinkedIn ? "noopener noreferrer" : undefined}
                    >
                      <LinkedInIcon />
                    </a>

                    {/* Instagram: gradient idSuffix = index to keep each gradient unique */}
                    <a
                      href={hasInstagram ? member.instagram : "#"}
                      onClick={hasInstagram ? undefined : (e) => e.preventDefault()}
                      aria-label={`${member.name}'s Instagram`}
                      target={hasInstagram ? "_blank" : undefined}
                      rel={hasInstagram ? "noopener noreferrer" : undefined}
                    >
                      <InstagramIcon idSuffix={index} />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
