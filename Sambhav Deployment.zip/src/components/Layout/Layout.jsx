// src/components/Layout/Layout.jsx - UPDATED

import React, { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import Navbar from "../Navbar/Navbar.jsx";
import "./Layout.css";

export default function Layout() {
  // State to control navbar visibility, initialized from sessionStorage
  const [showNav, setShowNav] = useState(
    () => sessionStorage.getItem("loaderPlayed") === "true"
  );

  // Get the current page's path
  const location = useLocation();
  const isLandingPage = location.pathname === "/";

  // This function will be called by the Landingpage when the video ends
  const handleLoaderFinished = () => {
    setShowNav(true);
  };

  // Determine if the navbar should be rendered.
  const shouldShowNav = !isLandingPage || showNav;

  return (
    <>
      {shouldShowNav && <Navbar />}
      <main className="layout-main">
        <div className="container">
          {/* Pass the function down to child routes via context */}
          <Outlet context={{ onLoaderFinished: handleLoaderFinished }} />
        </div>
      </main>
    </>
  );
}